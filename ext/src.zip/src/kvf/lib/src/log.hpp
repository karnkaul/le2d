#pragma once
#include <klib/log.hpp>

namespace kvf {
auto const log = klib::TaggedLogger{"kvf"};
} // namespace kvf
