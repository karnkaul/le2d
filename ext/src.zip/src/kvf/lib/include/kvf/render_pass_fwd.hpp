#pragma once

namespace kvf {
class RenderPass;
} // namespace kvf
