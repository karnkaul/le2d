#pragma once

namespace kvf {
class RenderDevice;
} // namespace kvf
