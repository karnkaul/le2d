#pragma once
#include <klib/log.hpp>

namespace kvf::example {
auto const log = klib::TaggedLogger{"kvf::example"};
} // namespace kvf::example
