#pragma once
#include <string_view>

namespace capo::detail {
void dispatch_error(std::string_view error);
} // namespace capo::detail
